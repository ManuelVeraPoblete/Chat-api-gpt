import { Module } from '@nestjs/common';
import { CallsGateway } from './calls.gateway';

/**
 * ✅ CallsModule
 * - Contiene el Gateway de signaling para llamadas (audio/video)
 * - NO transmite media (solo señalización WebRTC)
 */
@Module({
  providers: [CallsGateway],
})
export class CallsModule {}
